using NeoModLoader.api;

namespace ExampleMod.UI.Windows;

public class ExampleWideWindow : AbstractWideWindow<ExampleWideWindow>
{
    protected override void Init()
    {
    }
}