using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

using UnityEngine;
using HarmonyLib;

using NeoModLoader.api;
using NeoModLoader.services;

namespace CatapultMod
{
    public class ModClass : MonoBehaviour, IMod
    {
        private ModDeclare _declare;
        private GameObject _go;

        public ModDeclare GetDeclaration() => _declare;
        public GameObject GetGameObject() => _go;
        public string GetUrl() => "";

        public void OnLoad(ModDeclare pModDecl, GameObject pGameObject)
        {
            _declare = pModDecl;
            _go = pGameObject;

            LogService.LogInfo("[Catapult] loaded! (UNIT mode, barracks-anchored, layer=from barracks + offset)");

            CatapultUnitStage.SetModDeclare(pModDecl);
            CatapultUnitStage.Init();

            try
            {
                if (_go.GetComponent<CatapultRuntimeCleaner>() == null)
                    _go.AddComponent<CatapultRuntimeCleaner>();
            }
            catch { }
        }
    }

    public class CatapultUnitMarker : MonoBehaviour { }

    public class CatapultRuntimeCleaner : MonoBehaviour
    {
        private float _nextCheck;
        private void Update()
        {
            if (Time.realtimeSinceStartup < _nextCheck) return;
            _nextCheck = Time.realtimeSinceStartup + 2f;
            CatapultUnitStage.CleanupIfNoCities();
        }
    }

    public static class CatapultUnitStage
    {
        // ===== Настройки =====
        private const float UNIT_SCALE = 0.30f;
        private const float SCAN_INTERVAL = 2.0f;
        private const float TOP_Z = 0f;

        // ===== ВОТ ЭТО ТЫ МЕНЯЕШЬ ДЛЯ "ВЫСОТЫ" В ПЕРЕКРЫТИИ =====
        //  0  = как у казармы
        // -5  = чуть ниже казармы (катапульту чаще перекрывают)
        // -20 = сильно ниже (почти всё перекрывает катапульту)
        // +10 = выше казармы (катапульта начнет перекрывать больше)
        private const int CATAPULT_LAYER_OFFSET = +5;

        // Если вдруг казарма не найдена/без спрайта — берем ближайший SpriteRenderer в радиусе
        private const float NEAREST_SPRITE_RADIUS = 7f;

        private static Material _spriteDefaultMat;

        private static readonly string[] BARRACKS_IDS =
        {
            "barracks_human","barracks_elf","barracks_dwarf","barracks_orc"
        };

        private static bool _inited;
        private static ModDeclare _decl;

        private static ConditionalWeakTable<City, CityUnitState> _cityUnits = new();
        private sealed class CityUnitState
        {
            public float nextScan;
            public GameObject unitGo;
            public object anchorBuilding;
        }

        private static Sprite _catapultSprite;
        private static bool _spriteLoaded;
        private static float _nextSpriteTryTime;
        private static bool _spriteWarned;

        public static void SetModDeclare(ModDeclare d) => _decl = d;

        public static void Init()
        {
            if (_inited) return;
            _inited = true;

            TryCacheDefaultSpriteMaterial();

            // Загружаем спрайт сразу (чтобы на первом спавне не было "невидимо")
            if (!_spriteLoaded)
                TryLoadSpriteOrPlaceholder();

            var h = new Harmony("catapult.unitmode.layer_from_barracks");
            h.PatchAll(Assembly.GetExecutingAssembly());

            Debug.Log("[Catapult] UnitStage ready. Layer comes from barracks + offset: " + CATAPULT_LAYER_OFFSET);
        }

        private static void TryCacheDefaultSpriteMaterial()
        {
            try
            {
                var shader = Shader.Find("Sprites/Default");
                if (shader != null) _spriteDefaultMat = new Material(shader);
            }
            catch { }
        }

        [HarmonyPatch]
        private static class PatchWorldResetHooks
        {
            static IEnumerable<MethodBase> TargetMethods()
            {
                var list = new List<MethodBase>();
                var candidates = new List<Type>
                {
                    typeof(World),
                    AccessTools.TypeByName("MapBox"),
                    AccessTools.TypeByName("MapGenerator"),
                    AccessTools.TypeByName("WorldGenerator"),
                    AccessTools.TypeByName("WorldLoader"),
                    AccessTools.TypeByName("SaveManager")
                };

                string[] names =
                {
                    "clearWorld","ClearWorld",
                    "clear","Clear",
                    "resetWorld","ResetWorld",
                    "generateNewMap","GenerateNewMap",
                    "GenerateMap","generateMap",
                    "loadWorld","LoadWorld",
                    "loadMap","LoadMap"
                };

                foreach (var t in candidates)
                {
                    if (t == null) continue;
                    foreach (var n in names)
                    {
                        try
                        {
                            var ms = t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static)
                                      .Where(m => m.Name == n).ToArray();
                            for (int i = 0; i < ms.Length; i++) list.Add(ms[i]);
                        }
                        catch { }
                    }
                }
                return list;
            }

            static void Prefix(MethodBase __originalMethod)
            {
                try { HardCleanup("[Hook] " + (__originalMethod != null ? __originalMethod.Name : "unknown")); }
                catch { }
            }
        }

        [HarmonyPatch(typeof(City), "update")]
        private static class PatchCityUpdate
        {
            private static void Postfix(City __instance)
            {
                if (__instance == null) return;
                float now = Time.realtimeSinceStartup;

                // периодически пробуем загрузить спрайт, если вдруг не получилось сразу
                if (!_spriteLoaded && now >= _nextSpriteTryTime)
                {
                    _nextSpriteTryTime = now + 8f;
                    TryLoadSpriteOrPlaceholder();
                }

                var st = _cityUnits.GetOrCreateValue(__instance);
                if (st.nextScan <= 0f) st.nextScan = now + 1.5f;
                if (now < st.nextScan) return;
                st.nextScan = now + SCAN_INTERVAL;

                object barracksBuilding = FindBarracksBuildingInCity(__instance);
                if (barracksBuilding == null)
                {
                    if (st.unitGo != null) { UnityEngine.Object.Destroy(st.unitGo); st.unitGo = null; st.anchorBuilding = null; }
                    return;
                }

                object tile = TryGetObj(barracksBuilding, "tile", "currentTile", "curTile", "Tile", "current_tile");
                if (tile == null || LooksLikeWaterTile(tile))
                {
                    if (st.unitGo != null) { UnityEngine.Object.Destroy(st.unitGo); st.unitGo = null; st.anchorBuilding = null; }
                    return;
                }

                if (!TryGetTileWorldPos(tile, out Vector3 tpos) || !IsWorldPosInsideMap(tpos))
                {
                    if (st.unitGo != null) { UnityEngine.Object.Destroy(st.unitGo); st.unitGo = null; st.anchorBuilding = null; }
                    return;
                }

                // создаем
                if (st.unitGo == null)
                {
                    st.anchorBuilding = barracksBuilding;
                    st.unitGo = SpawnCatapultUnitAt(tpos, barracksBuilding);
                    return;
                }

                // двигаем за казармой
                Vector3 p = tpos + new Vector3(0.35f, 0.15f, 0f);
                p.z = TOP_Z;
                st.unitGo.transform.position = p;

                // обновляем видимость + слои от якоря
                ForceVisible(st.unitGo, barracksBuilding);
            }
        }

        private static GameObject SpawnCatapultUnitAt(Vector3 tilePos, object anchorBuilding)
        {
            Vector3 pos = tilePos + new Vector3(0.35f, 0.15f, 0f);
            pos.z = TOP_Z;

            var go = new GameObject("CatapultUnit");
            go.AddComponent<CatapultUnitMarker>();
            go.transform.position = pos;
            go.transform.localScale = Vector3.one * UNIT_SCALE;

            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = _catapultSprite;

            ForceVisible(go, anchorBuilding);
            return go;
        }

        private static void ForceVisible(GameObject go, object anchorBuilding)
        {
            if (go == null) return;

            var sr = go.GetComponent<SpriteRenderer>();
            if (sr == null) return;

            sr.enabled = true;
            sr.color = new Color(1f, 1f, 1f, 1f);

            if (_spriteDefaultMat != null)
            {
                try { sr.sharedMaterial = _spriteDefaultMat; } catch { }
            }

            // --- ВОТ ГЛАВНОЕ ИЗ "НЕСКОЛЬКИХ СООБЩЕНИЙ ВЫШЕ" ---
            // 1) Пытаемся взять sortingLayerName/sortingOrder от казармы (якоря)
            // 2) Если не вышло — берём ближайший SpriteRenderer в радиусе
            ApplyLayerFromAnchorOrNearest(sr, anchorBuilding, go.transform.position);

            var p = go.transform.position;
            if (p.z != TOP_Z)
            {
                p.z = TOP_Z;
                go.transform.position = p;
            }
        }

        private static void ApplyLayerFromAnchorOrNearest(SpriteRenderer catSr, object anchorBuilding, Vector3 pos)
        {
            if (catSr == null) return;

            // 1) Сначала пробуем якорь (казарму)
            var anchorSr = GetSpriteRendererFromUnknown(anchorBuilding);
            if (anchorSr != null && !string.IsNullOrEmpty(anchorSr.sortingLayerName))
            {
                catSr.sortingLayerName = anchorSr.sortingLayerName;
                catSr.sortingOrder = anchorSr.sortingOrder + CATAPULT_LAYER_OFFSET;
                return;
            }

            // 2) Фолбек: ближайший SpriteRenderer в радиусе
            SpriteRenderer best = null;
            float bestDist = float.MaxValue;
            float r2 = NEAREST_SPRITE_RADIUS * NEAREST_SPRITE_RADIUS;

            SpriteRenderer[] all;
            try { all = UnityEngine.Object.FindObjectsOfType<SpriteRenderer>(); }
            catch { all = null; }

            if (all != null)
            {
                for (int i = 0; i < all.Length; i++)
                {
                    var sr = all[i];
                    if (sr == null) continue;
                    if (sr == catSr) continue;
                    if (!sr.enabled) continue;
                    if (sr.sprite == null) continue;

                    // отсекаем UI/иконки (могут ломать выбор слоя)
                    string layerName = sr.sortingLayerName ?? "";
                    if (layerName.IndexOf("ui", StringComparison.OrdinalIgnoreCase) >= 0) continue;

                    Vector3 sp = sr.transform.position;
                    float dx = sp.x - pos.x;
                    float dy = sp.y - pos.y;
                    float d2 = dx * dx + dy * dy;
                    if (d2 > r2) continue;

                    if (d2 < bestDist)
                    {
                        bestDist = d2;
                        best = sr;
                    }
                }
            }

            if (best != null && !string.IsNullOrEmpty(best.sortingLayerName))
            {
                catSr.sortingLayerName = best.sortingLayerName;
                catSr.sortingOrder = best.sortingOrder + CATAPULT_LAYER_OFFSET;
                return;
            }

            // 3) Самый последний фолбек
            catSr.sortingLayerName = "Default";
            catSr.sortingOrder = CATAPULT_LAYER_OFFSET;
        }

        private static SpriteRenderer GetSpriteRendererFromUnknown(object maybeObj)
        {
            if (maybeObj == null) return null;

            try
            {
                if (maybeObj is GameObject go)
                    return go.GetComponentInChildren<SpriteRenderer>(true);

                if (maybeObj is Component c)
                    return c.GetComponentInChildren<SpriteRenderer>(true);

                // через reflection: gameObject / transform
                object goObj = TryGetObj(maybeObj, "gameObject", "go", "Go", "_go");
                if (goObj is GameObject go2)
                    return go2.GetComponentInChildren<SpriteRenderer>(true);

                object trObj = TryGetObj(maybeObj, "transform", "Transform");
                if (trObj is Transform tr)
                    return tr.GetComponentInChildren<SpriteRenderer>(true);
            }
            catch { }

            return null;
        }

        public static void CleanupIfNoCities()
        {
            try
            {
                int cityCount = CountCitiesFromWorldReflection();
                if (cityCount > 0) return;

                if (CountCatapultUnitsInScene() > 0)
                    HardCleanup("[Watchdog] no cities");
            }
            catch { }
        }

        // ===== Поиск казармы в городе =====
        private static object FindBarracksBuildingInCity(City city)
        {
            try
            {
                var list = city.buildings;
                if (list == null) return null;

                foreach (var b in list)
                {
                    var a = TryExtractBuildingAsset(b);
                    if (a == null) continue;
                    if (BARRACKS_IDS.Any(id => string.Equals(a.id, id, StringComparison.OrdinalIgnoreCase)))
                        return b;
                }

                foreach (var b in list)
                {
                    var a = TryExtractBuildingAsset(b);
                    if (a == null) continue;
                    if (!string.IsNullOrEmpty(a.id) && a.id.StartsWith("barracks_", StringComparison.OrdinalIgnoreCase))
                        return b;
                }
            }
            catch { }
            return null;
        }

        private static BuildingAsset TryExtractBuildingAsset(object building)
        {
            try
            {
                var a = TryGetObj(building, "asset", "Asset", "buildingAsset", "data", "building_data");
                return a as BuildingAsset;
            }
            catch { return null; }
        }

        // ===== tile helpers =====
        private static bool TryGetTileWorldPos(object tile, out Vector3 pos)
        {
            pos = Vector3.zero;
            if (tile == null) return false;

            var v3 = TryGetValue<Vector3>(tile, "worldPos", "worldPosition", "pos", "position");
            if (v3.HasValue) { pos = v3.Value; return true; }

            var v2 = TryGetValue<Vector2>(tile, "worldPos", "worldPosition", "pos", "position");
            if (v2.HasValue) { pos = new Vector3(v2.Value.x, v2.Value.y, 0f); return true; }

            int? tx = TryGetValue<int>(tile, "x", "tileX", "posX", "px", "cellX");
            int? ty = TryGetValue<int>(tile, "y", "tileY", "posY", "py", "cellY");
            if (tx.HasValue && ty.HasValue) { pos = new Vector3(tx.Value, ty.Value, 0f); return true; }

            return false;
        }

        private static bool LooksLikeWaterTile(object tile)
        {
            if (tile == null) return true;

            bool? b = TryGetValue<bool>(tile, "isWater", "water", "isOcean", "ocean", "isLiquid", "liquid", "isSea", "sea");
            if (b.HasValue) return b.Value;

            try
            {
                var mw = InvokeInstanceMethodAnyOverload(tile, "isWater") ?? InvokeInstanceMethodAnyOverload(tile, "IsWater");
                if (mw is bool bw) return bw;
            }
            catch { }

            object typeObj = TryGetObj(tile, "type", "tileType", "groundType", "biomeType", "mainType");
            if (typeObj != null)
            {
                string s = typeObj.ToString().ToLowerInvariant();
                if (s.Contains("water") || s.Contains("ocean") || s.Contains("sea") || s.Contains("lake") || s.Contains("river"))
                    return true;
            }

            int? liquid = TryGetValue<int>(tile, "liquid", "liquidType", "waterType");
            if (liquid.HasValue && liquid.Value != 0) return true;

            return false;
        }

        private static bool IsWorldPosInsideMap(Vector3 pos)
        {
            if (float.IsNaN(pos.x) || float.IsNaN(pos.y) || float.IsInfinity(pos.x) || float.IsInfinity(pos.y))
                return false;

            if (pos.x <= 0.5f || pos.y <= 0.5f) return false;

            if (TryGetMapSize(out int w, out int h))
            {
                if (pos.x >= w - 0.5f || pos.y >= h - 0.5f) return false;
            }
            return true;
        }

        private static bool TryGetMapSize(out int w, out int h)
        {
            w = 0; h = 0;
            try
            {
                object world = GetStaticPropertyOrField(typeof(World), "world")
                           ?? GetStaticPropertyOrField(typeof(World), "instance")
                           ?? GetStaticPropertyOrField(typeof(World), "World");
                if (world == null) return false;

                int? ww = TryGetValue<int>(world, "width", "mapWidth", "worldWidth");
                int? hh = TryGetValue<int>(world, "height", "mapHeight", "worldHeight");
                if (ww.HasValue && hh.HasValue && ww.Value > 0 && hh.Value > 0)
                {
                    w = ww.Value; h = hh.Value; return true;
                }

                var map = TryGetObj(world, "map", "_map", "Map");
                if (map != null)
                {
                    ww = TryGetValue<int>(map, "width", "mapWidth", "w");
                    hh = TryGetValue<int>(map, "height", "mapHeight", "h");
                    if (ww.HasValue && hh.HasValue && ww.Value > 0 && hh.Value > 0)
                    {
                        w = ww.Value; h = hh.Value; return true;
                    }
                }
            }
            catch { }
            return false;
        }

        // ===== sprites =====
        private static void TryLoadSpriteOrPlaceholder()
        {
            try
            {
                string modDir = ResolveModDirFromDeclare(_decl);

                if (!string.IsNullOrEmpty(modDir))
                {
                    string spritesDir = Path.Combine(modDir, "sprites");

                    string path = FirstExisting(
                        Path.Combine(spritesDir, "catapult_unit.png"),
                        Path.Combine(spritesDir, "catapult_big.png"),
                        Path.Combine(spritesDir, "catapult_big.jpg")
                    );

                    if (path != null)
                    {
                        _catapultSprite = LoadSpriteFromFile(path, 64f);
                        _spriteLoaded = _catapultSprite != null;
                        if (_spriteLoaded)
                        {
                            Debug.Log("[Catapult] Unit sprite loaded: " + path);
                            return;
                        }
                    }

                    if (!_spriteWarned)
                    {
                        _spriteWarned = true;
                        Debug.Log("[Catapult] Sprite not found in: " + spritesDir + " (using placeholder)");
                    }
                }
            }
            catch { }

            _catapultSprite = CreatePlaceholderSprite(64, 64, 64f);
            _spriteLoaded = _catapultSprite != null;
        }

        private static Sprite LoadSpriteFromFile(string path, float ppu)
        {
            byte[] bytes = File.ReadAllBytes(path);
            var tex = new Texture2D(2, 2, TextureFormat.RGBA32, false, false);
            if (!tex.LoadImage(bytes)) return null;

            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;

            return Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), ppu);
        }

        private static Sprite CreatePlaceholderSprite(int w, int h, float ppu)
        {
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;

            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                bool border = (x == 0 || y == 0 || x == w - 1 || y == h - 1);
                bool cross = (x == y) || (x == (w - 1 - y));
                var c = (border || cross) ? new Color(0.1f, 0.1f, 0.1f, 1f) : new Color(0.9f, 0.75f, 0.45f, 1f);
                tex.SetPixel(x, y, c);
            }
            tex.Apply();

            return Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), ppu);
        }

        private static string FirstExisting(params string[] paths)
        {
            foreach (var p in paths)
                if (!string.IsNullOrEmpty(p) && File.Exists(p))
                    return p;
            return null;
        }

        private static string ResolveModDirFromDeclare(ModDeclare decl)
        {
            if (decl == null) return null;

            try
            {
                var t = decl.GetType();
                const BindingFlags BF = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

                foreach (var f in t.GetFields(BF))
                {
                    if (f.FieldType != typeof(string)) continue;
                    var s = f.GetValue(decl) as string;
                    if (!string.IsNullOrEmpty(s) && Directory.Exists(s)) return s;
                }

                foreach (var p in t.GetProperties(BF))
                {
                    if (!p.CanRead || p.PropertyType != typeof(string)) continue;
                    var s = p.GetValue(decl) as string;
                    if (!string.IsNullOrEmpty(s) && Directory.Exists(s)) return s;
                }
            }
            catch { }

            return null;
        }

        // ===== cleanup =====
        private static int CountCitiesFromWorldReflection()
        {
            object world = GetStaticPropertyOrField(typeof(World), "world")
                        ?? GetStaticPropertyOrField(typeof(World), "instance")
                        ?? GetStaticPropertyOrField(typeof(World), "World");
            if (world == null) return 0;

            try
            {
                var t = world.GetType();
                const BindingFlags BF = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

                var f = t.GetField("cities", BF);
                if (f != null) return GetCollectionCount(f.GetValue(world));

                var p = t.GetProperty("cities", BF);
                if (p != null && p.CanRead) return GetCollectionCount(p.GetValue(world));
            }
            catch { }

            return 0;
        }

        private static int GetCollectionCount(object collection)
        {
            if (collection == null) return 0;
            try { if (collection is System.Collections.ICollection col) return col.Count; } catch { }
            try
            {
                if (collection is System.Collections.IEnumerable en)
                {
                    int c = 0; foreach (var _ in en) c++; return c;
                }
            }
            catch { }
            return 0;
        }

        private static int CountCatapultUnitsInScene()
        {
            try
            {
                var markers = Resources.FindObjectsOfTypeAll<CatapultUnitMarker>();
                return markers != null ? markers.Length : 0;
            }
            catch { return 0; }
        }

        private static void HardCleanup(string reason)
        {
            try
            {
                var markers = Resources.FindObjectsOfTypeAll<CatapultUnitMarker>();
                if (markers != null)
                {
                    for (int i = 0; i < markers.Length; i++)
                        if (markers[i] != null && markers[i].gameObject != null)
                            UnityEngine.Object.Destroy(markers[i].gameObject);
                }
            }
            catch { }

            _cityUnits = new ConditionalWeakTable<City, CityUnitState>();
            Debug.Log("[Catapult] HardCleanup done: " + reason);
        }

        // ===== reflection utils =====
        private static object TryGetObj(object obj, params string[] names)
        {
            if (obj == null) return null;
            var t = obj.GetType();
            const BindingFlags BF = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            foreach (var n in names)
            {
                var f = t.GetField(n, BF);
                if (f != null) { try { return f.GetValue(obj); } catch { } }

                var p = t.GetProperty(n, BF);
                if (p != null && p.CanRead) { try { return p.GetValue(obj); } catch { } }
            }
            return null;
        }

        private static T? TryGetValue<T>(object obj, params string[] names) where T : struct
        {
            if (obj == null) return null;
            var t = obj.GetType();
            const BindingFlags BF = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            foreach (var n in names)
            {
                var f = t.GetField(n, BF);
                if (f != null && f.FieldType == typeof(T)) { try { return (T)f.GetValue(obj); } catch { } }

                var p = t.GetProperty(n, BF);
                if (p != null && p.CanRead && p.PropertyType == typeof(T)) { try { return (T)p.GetValue(obj); } catch { } }
            }
            return null;
        }

        private static object GetStaticPropertyOrField(Type t, string name)
        {
            var p = t.GetProperty(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (p != null) return p.GetValue(null);

            var f = t.GetField(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (f != null) return f.GetValue(null);

            return null;
        }

        private static object InvokeInstanceMethodAnyOverload(object obj, string methodName, params object[] args)
        {
            if (obj == null) return null;

            var t = obj.GetType();
            var methods = t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                .Where(m => m.Name == methodName).ToList();

            foreach (var m in methods)
            {
                var ps = m.GetParameters();
                if (ps.Length != (args?.Length ?? 0)) continue;
                try { return m.Invoke(obj, args); } catch { }
            }
            return null;
        }
    }
}
